const lang = 'en-GB'
const voiceIndex = 1

const speak = async text => {
  if (!speechSynthesis) {
    return
  }
  const message = new SpeechSynthesisUtterance(text)
  message.voice = await chooseVoice()
  speechSynthesis.speak(message)
}

const getVoices = () => {
  return new Promise(resolve => {
    let voices = speechSynthesis.getVoices()
    if (voices.length) {
      resolve(voices)
      return
    }
    speechSynthesis.onvoiceschanged = () => {
      voices = speechSynthesis.getVoices()
      resolve(voices)
    }
  })
}

const chooseVoice = async () => {
  const voices = (await getVoices()).filter(voice => voice.lang == lang)

  return new Promise(resolve => {
    resolve(voices[voiceIndex])
  })
}

speak('In the land of a million drums, There is always something going on, on, on, on, If you cant locate your thought off. Might as well go on take your dead home, home, home, home. In the land of a million drums. I catch a pattern that spit rings around you like Saturn. Intergalactic tracks, I make em like magstrulium. This one for Scooby, pass the doobie Imma do me one, do me one, only you clean Over. I pick up the mic and rock it while Im sober. For the rated G exposure if you listen to what Im tryin to told ya. We fathers with seeds of our own. Were talking about sons and daughters boy, not roots and clones, Now that the theory gone wrong. An embryo with no soul. Stuck in this green mini-van with my lungs in a choke hold. Shaggy, pass the bombastic, Daphne said, Dont do that. Freaky Fred smashed the gas and slammed us into traffic. Now Scrappy want to box and throw them bows. So I had to sic the pitbull on him before he could pass one blow. Scooby-Doo, Scooby-Doo, Scooby-Doo, Scooby-Doo');